Thanks for using my mod installer for No Man's Sky. 
I realized that installing mods for the game was relatively easy but repetitive for
people who were constantly changing what mods they were using.
So I created this easy to use script that will take care of the steps for you,
and voila!

All mods you want installed need to be placed as their .pak filetypes in the 'Mods' folder.

After this simply run the script.